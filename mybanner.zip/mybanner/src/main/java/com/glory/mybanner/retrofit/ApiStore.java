package com.glory.mybanner.retrofit;

import com.glory.mybanner.BannerModel;

import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Create by glorizz on 2018/7/17
 * Describe:
 */
public interface ApiStore {
     String API_SERVER_URL = "http://124.205.9.251:8082/";//北京

    //轮播图
    @POST("/mobile/index/noticeList")
    Call<BannerModel> bannerData(@Query("notice_type") String notice_type);
}
